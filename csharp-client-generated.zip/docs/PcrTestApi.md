# IO.Swagger.Api.PcrTestApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**PcrtestGet**](PcrTestApi.md#pcrtestget) | **GET** /pcrtest | Get the list of pcr tests
[**PcrtestIdDelete**](PcrTestApi.md#pcrtestiddelete) | **DELETE** /pcrtest/{id} | Delete the pcr test with specified id
[**PcrtestIdGet**](PcrTestApi.md#pcrtestidget) | **GET** /pcrtest/{id} | Get the pcr test with specified id
[**PcrtestIdPut**](PcrTestApi.md#pcrtestidput) | **PUT** /pcrtest/{id} | Update the pcr test with the given id
[**PcrtestPost**](PcrTestApi.md#pcrtestpost) | **POST** /pcrtest | Create a pcr test with given model

<a name="pcrtestget"></a>
# **PcrtestGet**
> List<PcrTest> PcrtestGet ()

Get the list of pcr tests

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PcrtestGetExample
    {
        public void main()
        {
            var apiInstance = new PcrTestApi();

            try
            {
                // Get the list of pcr tests
                List&lt;PcrTest&gt; result = apiInstance.PcrtestGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PcrTestApi.PcrtestGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<PcrTest>**](PcrTest.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="pcrtestiddelete"></a>
# **PcrtestIdDelete**
> void PcrtestIdDelete (Guid? id)

Delete the pcr test with specified id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PcrtestIdDeleteExample
    {
        public void main()
        {
            var apiInstance = new PcrTestApi();
            var id = new Guid?(); // Guid? | id of the pcr test

            try
            {
                // Delete the pcr test with specified id
                apiInstance.PcrtestIdDelete(id);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PcrTestApi.PcrtestIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | [**Guid?**](Guid?.md)| id of the pcr test | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="pcrtestidget"></a>
# **PcrtestIdGet**
> PcrTest PcrtestIdGet (Guid? id)

Get the pcr test with specified id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PcrtestIdGetExample
    {
        public void main()
        {
            var apiInstance = new PcrTestApi();
            var id = new Guid?(); // Guid? | id of the pcr test

            try
            {
                // Get the pcr test with specified id
                PcrTest result = apiInstance.PcrtestIdGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PcrTestApi.PcrtestIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | [**Guid?**](Guid?.md)| id of the pcr test | 

### Return type

[**PcrTest**](PcrTest.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="pcrtestidput"></a>
# **PcrtestIdPut**
> void PcrtestIdPut (Guid? id, PcrTest body = null)

Update the pcr test with the given id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PcrtestIdPutExample
    {
        public void main()
        {
            var apiInstance = new PcrTestApi();
            var id = new Guid?(); // Guid? | id of the pcr test
            var body = new PcrTest(); // PcrTest | pcr test model (optional) 

            try
            {
                // Update the pcr test with the given id
                apiInstance.PcrtestIdPut(id, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PcrTestApi.PcrtestIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | [**Guid?**](Guid?.md)| id of the pcr test | 
 **body** | [**PcrTest**](PcrTest.md)| pcr test model | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="pcrtestpost"></a>
# **PcrtestPost**
> void PcrtestPost (PcrTest body = null)

Create a pcr test with given model

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PcrtestPostExample
    {
        public void main()
        {
            var apiInstance = new PcrTestApi();
            var body = new PcrTest(); // PcrTest | pcr test model (optional) 

            try
            {
                // Create a pcr test with given model
                apiInstance.PcrtestPost(body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PcrTestApi.PcrtestPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PcrTest**](PcrTest.md)| pcr test model | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/_*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
