# IO.Swagger.Model.PcrTest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **Guid?** |  | [optional] 
**Code** | **string** |  | 
**Comment** | **string** |  | [optional] 
**ReceptionDate** | **DateTime?** |  | [optional] 
**AnalysisDate** | **DateTime?** |  | [optional] 
**Result** | **ResultEnum** |  | [optional] 
**PerformerPersonId** | **Guid?** |  | [optional] 
**PerformerPerson** | [**Person**](Person.md) |  | [optional] 
**Observations** | [**List&lt;Observation&gt;**](Observation.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

