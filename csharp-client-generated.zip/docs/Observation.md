# IO.Swagger.Model.Observation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **Guid?** |  | [optional] 
**DateTime** | **DateTime?** |  | 
**Comment** | **string** |  | 
**PcrTestId** | **Guid?** |  | [optional] 
**PcrTest** | [**PcrTest**](PcrTest.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

